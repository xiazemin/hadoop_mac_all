#!/bin/bash
curDir=`pwd`
cd /Users/didi/kafka/server1/kafka_2.10-0.8.2.1/bin
./kafka-server-start.sh -daemon ../config/server.properties

jps


cd /Users/didi/kafka/server2/kafka_2.10-0.8.2.1/bin
./kafka-server-start.sh -daemon ../config/server.properties

jps

cd $curDir
