#!/bin/bash
curDir=`pwd`
cd /Users/didi/zookeeper/server1/zookeeper-3.4.6/bin/
./zkServer.sh start

#/Users/didi/zookeeper/server1/zookeeper-3.4.6/bin/
./zkServer.sh status

cd /Users/didi/zookeeper/server2/zookeeper-3.4.6/bin/

./zkServer.sh start

#/Users/didi/zookeeper/server2/zookeeper-3.4.6/bin/

./zkServer.sh status

cd /Users/didi/zookeeper/server3/zookeeper-3.4.6/bin/

./zkServer.sh start

#/Users/didi/zookeeper/server3/zookeeper-3.4.6/bin/

./zkServer.sh status

cd $curDir
